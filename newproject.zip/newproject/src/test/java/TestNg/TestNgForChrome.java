package TestNg;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Utilities.ExplicitCode;
import datepicker.dateobj;

import pomPages.AfterSearch;
import pomPages.FirstPage;



public class TestNgForChrome extends ExplicitCode{//here we extends explicit code for acquiring properties  and variables of explicit code
	WebDriver dr;
	
	 FirstPage vp;
	 AfterSearch sp;
     dateobj d;
	@BeforeMethod
	public void LB() {
		launchbrowser("chrome");
	}
	@BeforeClass
	public void GE() {
		getExcel("Sheet1");
	}
    @Test(dataProvider="register")
    public void process(String s1,String s2) {
    	vp= new FirstPage(dr);
    	sp= new AfterSearch(dr);
    	d=new dateobj(dr);
    	vp.travel(s1, s2);
    	d.datepicker();
    	sp.BusName();
    	
    }
	
	 @DataProvider(name="register")
	  public String[][] register(){
		   return testdata;
	  }
	// @AfterMethod
	 public void CB() {
		 dr.quit();//closing the current window
	 }
}
