package datepicker;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.ExplicitCode;


public class dateobj {
	WebDriver dr;
	ExplicitCode  e;	
	public  dateobj(WebDriver dr) {
		this.dr=dr;
		e=new ExplicitCode ();
	}
	String s="June 2020";
	By click1=
			By.xpath("//div[@id='selectDate']");
	
	
	By date=By.xpath("//div[@class='pika-lendar'][2]//table//tr");
	By Search=By.xpath("//button[@class='ty-button ty-button-orange']");
	public void clicking() {
		WebElement a=e.clickable(click1, 100);
		a.click();
	}
	public void datepicker() {
	dr.findElement(click1).click();
	
		 List<WebElement> all=dr.findElements(date);
			for(WebElement f:all){
				String date=f.getText();
				if(date.equalsIgnoreCase("5")) {
					f.click();
					break;
				}
			}
			WebElement a=e.clickable(Search, 100);
			a.click();	
	 }
	}

