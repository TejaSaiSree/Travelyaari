package pomPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Utilities.ExplicitCode;




public class AfterSearch {
	WebDriver dr;
	ExplicitCode  e;
	public AfterSearch(WebDriver dr) {
		this.dr=dr;
		e= new ExplicitCode();
	}
	By busname=By.xpath("//div[@class='label-blk'][1]");
	
	public String BusName() {
String s=dr.findElement(busname).getText();
e.Screenshot();
return s;

	}
	
	}

