package pomPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.ExplicitCode;

public class FirstPage {
	WebDriver dr;
	ExplicitCode ec;
	//constructor
public FirstPage(WebDriver dr) {
	this.dr=dr;
	ec= new ExplicitCode();
	
}
//xpath for verify products
By alert=By.xpath("//div[@id='crossCor']");
By fromdate=By.xpath("//form[@id='search-form']//div[1]//div[1]");
By todate=By.xpath("//form[@id='search-form']//div[3]//input[1]");
 
//pom methods for xpaths
public void Alert() {
	 WebElement a=ec.clickable(alert, 50);
	 a.click();
}
public void FromDate(String s) {
	 WebElement a=ec.clickable(fromdate, 50);
	 a.sendKeys(s);
	 
}
public void ToDate(String s) {
	 WebElement a=ec.waitelement(todate, 20);
	a.sendKeys(s);
}

public void travel(String s1,String s2) {
	this.Alert();
	this.ToDate(s1);
	this.FromDate(s2);
	
}
}
